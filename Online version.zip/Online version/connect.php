<?php

$servername = "localhost";
$username = "u210688";
$password = "Yrp4Oj8cv";
$db = "u210688_vrij"; //naam van de database

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error){
    echo "Connection Failed";
    die($conn->connect_error);
}
?>