<?php
function mailer($voornaam, $email, $tel_nummer, $message, $category_product){


$subject = 'Bevestigings Mail';

$message_email = '

<html>
<head>
    <title>Bevestiging</title>
</head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
a{
  color: black;
  text-decoration: none;
}
a:hover{
  color: blue;
}
</style>
<body>
<h2> Bedankt voor u inzending </h2>
<p> Beste '.$voornaam.', </p>
<p> Bedankt voor u inzending. </p>
<p> Hetgene wat u zou willen doneren kunt u hier onder in terug vinden samen met de gegevens die u aan ons heeft doorgegeven! </p>
<br>
<table>
<tr>
<th>Aanbod</th>
<th>Category</th>
</tr>
<tr>
<td>' .$message. ' </td>
<td>' .$category_product. ' </td>
</table>
<h3>Uw gegevens </h3>
<table>
<tr>
<th> Email </th>
<th> Telefoon Nummer</th>
</tr>
<tr>
<td>'.$email.'</td>
<td>'.$tel_nummer.'</td>
</tr>
</table>
<br>
<i> Voor meer vragen zou u ons kunnen mailen of bellen via </i>
<p> 
  <a href="mailto:test@mail.nl">test@mail.nl</a>
   &
   <a href="tel:0611"> 0611 </a> </p>
<p> Bent u wat vergeten of wilt u nog meer aan ons aanbieden?</p>
<a href="#"> Klik hier</a>
</body>
</html>


';


$headers = "From: No-Reply Vrijwilligershuis Nieuwgein <no-reply@vrijwilligershuis-nieuwgein.nl>\r\n";
$headers .= "Reply-To: reply@vrijwilligershuis-nieuwgein.nl\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

mail($email, $subject, $message_email, $headers);
header('location:index.php');
}
?>